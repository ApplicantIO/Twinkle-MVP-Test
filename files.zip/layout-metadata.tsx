// app/layout.tsx — ROOT METADATA
// Buni hozirgi app/layout.tsx ga qo'shing (metadata export'ni almashtiring)

import type { Metadata } from "next";

const SITE_URL = "https://twinkle.uz";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),

  title: {
    default: "Twinkle — Kontent yaratuvchilar uchun monetizatsiya platformasi",
    template: "%s | Twinkle",
  },

  description:
    "Twinkle — O'zbekiston va Markaziy Osiyo kontent yaratuvchilari uchun video platforma. Obuna, donat va reklama orqali daromad ishlang. Blogerlar, streamerlar va podkasterlar uchun.",

  keywords: [
    "twinkle",
    "twinkle uz",
    "kontent yaratuvchilar uchun platforma",
    "kreator monetizatsiya platformasi",
    "donat platformasi",
    "creator monetization platform",
    "donation platform for creators",
    "платформа для монетизации контента",
    "донат платформа",
    "Uzbek YouTuber monetizatsiya",
    "streamerlar uchun donat",
    "kreator iqtisodiyoti",
    "video platforma o'zbekiston",
    "Central Asia creator economy",
    "obuna orqali pul ishlash",
    "blogerlik bilan pul topish",
  ],

  authors: [{ name: "Twinkle", url: SITE_URL }],
  creator: "Twinkle",
  publisher: "Twinkle",
  applicationName: "Twinkle",
  referrer: "origin-when-cross-origin",
  formatDetection: { email: false, address: false, telephone: false },

  alternates: {
    canonical: SITE_URL,
    languages: {
      "uz-UZ": SITE_URL,
      "ru-RU": `${SITE_URL}/ru`,
      "en-US": `${SITE_URL}/en`,
      "x-default": SITE_URL,
    },
  },

  openGraph: {
    type: "website",
    locale: "uz_UZ",
    alternateLocale: ["ru_RU", "en_US"],
    url: SITE_URL,
    siteName: "Twinkle",
    title: "Twinkle — Kontent yaratuvchilar uchun monetizatsiya platformasi",
    description:
      "O'zbekiston va Markaziy Osiyo kontent yaratuvchilari uchun video platforma. Obuna, donat va reklama orqali daromad ishlang.",
    images: [
      {
        url: `${SITE_URL}/og/default-og.png`,
        width: 1200,
        height: 630,
        alt: "Twinkle — Creator Monetization Platform",
        type: "image/png",
      },
    ],
  },

  twitter: {
    card: "summary_large_image",
    title: "Twinkle — Creator Monetization Platform",
    description:
      "O'zbekiston kreatorlari uchun daromad platformasi. Obuna, donat, reklama.",
    images: [`${SITE_URL}/og/default-og.png`],
    creator: "@twinkleuz",
    site: "@twinkleuz",
  },

  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },

  verification: {
    // Bularni Google/Yandex/Bing dashboard'laridan oling
    google: "GOOGLE_VERIFICATION_CODE",
    yandex: "YANDEX_VERIFICATION_CODE",
    other: {
      "msvalidate.01": "BING_VERIFICATION_CODE",
    },
  },

  category: "technology",
};
