// ─── app/watch/[id]/page.tsx — generateMetadata ─────────────────────────────
// Hozirgi watch page'ga qo'shing

import type { Metadata } from "next";

const SITE_URL = "https://twinkle.uz";

// WATCH PAGE
export async function generateMetadataWatch({
  params,
}: {
  params: { id: string };
}): Promise<Metadata> {
  // Video ma'lumotlarini API'dan oling
  const res = await fetch(`${SITE_URL}/api/videos/${params.id}`, {
    next: { revalidate: 3600 },
  });

  if (!res.ok) {
    return {
      title: "Video | Twinkle",
      description: "Twinkle platformasida video tomosha qiling.",
    };
  }

  const video = await res.json();

  const title = `${video.title} — ${video.creator?.name ?? "Twinkle"}`;
  const description =
    video.description?.slice(0, 160) ??
    `${video.title} — Twinkle platformasida tomosha qiling.`;

  return {
    title,
    description,
    alternates: {
      canonical: `${SITE_URL}/watch/${params.id}`,
    },
    openGraph: {
      type: "video.other",
      title,
      description,
      url: `${SITE_URL}/watch/${params.id}`,
      siteName: "Twinkle",
      images: [
        {
          url: video.thumbnailUrl ?? `${SITE_URL}/og/default-og.png`,
          width: 1280,
          height: 720,
          alt: video.title,
        },
      ],
      videos: [
        {
          url: video.videoUrl,
          type: "video/mp4",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [video.thumbnailUrl ?? `${SITE_URL}/og/default-og.png`],
    },
  };
}

// ─── app/[username]/page.tsx — generateMetadata ──────────────────────────────

export async function generateMetadataCreator({
  params,
}: {
  params: { username: string };
}): Promise<Metadata> {
  const res = await fetch(`${SITE_URL}/api/creators/${params.username}`, {
    next: { revalidate: 3600 },
  });

  if (!res.ok) {
    return {
      title: `@${params.username} | Twinkle`,
      description: "Twinkle'da creator profilini ko'ring.",
    };
  }

  const creator = await res.json();

  const title = `${creator.name} (@${params.username}) | Twinkle`;
  const description =
    creator.bio?.slice(0, 160) ??
    `${creator.name} Twinkle platformasida kontent yaratuvchi. ${creator.subscriberCount ?? 0} obunachilar.`;

  return {
    title,
    description,
    alternates: {
      canonical: `${SITE_URL}/${params.username}`,
    },
    openGraph: {
      type: "profile",
      title,
      description,
      url: `${SITE_URL}/${params.username}`,
      siteName: "Twinkle",
      images: [
        {
          url: creator.bannerUrl ?? creator.avatarUrl ?? `${SITE_URL}/og/default-og.png`,
          width: 1200,
          height: 630,
          alt: `${creator.name} — Twinkle`,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [creator.avatarUrl ?? `${SITE_URL}/og/default-og.png`],
    },
  };
}

// ─── app/search/page.tsx — generateMetadata ──────────────────────────────────

export async function generateMetadataSearch({
  searchParams,
}: {
  searchParams: { q?: string };
}): Promise<Metadata> {
  const query = searchParams.q ?? "";

  return {
    title: query
      ? `"${query}" — Qidiruv natijalari | Twinkle`
      : "Qidiruv | Twinkle",
    description: query
      ? `"${query}" bo'yicha Twinkle'dagi video va kreatorlar.`
      : "Twinkle'da video va kreatorlarni qidiring.",
    robots: {
      index: false, // search result pages indekslanmasin
      follow: true,
    },
  };
}
